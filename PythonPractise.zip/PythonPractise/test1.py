'''i_n=raw_input("Enter the no of iterations: ")

a=0
b=1
print 1,
for i in range(int(i_n) - 1):
    c = a + b
    a = b
    b = c
    print c,'''

#recursive

'''i_n=raw_input("Please enter no of iterations: ")

def fibo(n):
    if n<=1:
        return n
    else:
        return fibo(n-1)+fibo(n-2)

for i in range(1, int(i_n)+1):
    print fibo(i),'''
'''x=1
y=1
for i in range(0,20):
    print x,
    z=x
    x=y
    y=y+z'''

#factorial

def facto(n):
    if n==1:
        return 1
    else:
        return n*facto(n-1)
b=int(raw_input("Please enter a number for factorial: "))

if b<0 or b>10:
    print"The number should be in range 0 to 10"
elif b==0:
    print "Factorial of 0 is 1"
else:
    print "the factorial of",b,"is",facto(b)


