with open("sample.txt") as f:
    content=f.readlines()
for i in content:
    print len(i) - 1


