''' date and times can be used to generate file automatically with current date'''
import datetime
filename = datetime.datetime.now()

def writer(filename):
    with open(filename.strftime("%Y-%m-%d")+".txt", "w") as f:
        f.write("Hi, I am using datetime function")

writer(filename)