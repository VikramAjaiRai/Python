with open("data.txt","a") as d:
    user_input = raw_input("Enter a word: ")
    for i in user_input:
        while str(i) != "end":
            d.write(i)
            raw_input("Enter a word: ")
        else:
            break
