l=range(0,10)

for items in l:
    if items == 3 or items == 6 or items == 9:
        continue
    else:
        print items,