word = raw_input("Enter a string to reverse it: ")

def reverse_word(w):
    return w[::-1]
print reverse_word(word)