import time

def fibonacci(n):
    if n<=1:
        return n
    else:
        return (fibonacci(n-1)+fibonacci(n-2))
user_input = raw_input("Enter the iterations you want: ")
for i in range(int(user_input)):
    print fibonacci(i),
    time.sleep(1)