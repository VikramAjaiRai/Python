for item in range(1,51):
    if item%3 == 0 and item%5 !=0:
        print "fizz",
    elif item%5 == 0 and item%3!=0:
        print "buzz",
    elif item%3 == 0 and item%5 == 0:
        print "fizbuzz",
    else:
        print item,