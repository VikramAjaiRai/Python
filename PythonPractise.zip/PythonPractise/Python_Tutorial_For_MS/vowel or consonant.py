word = raw_input("Enter a word: ")
word_new = word.lower()

if word_new in ("a","e","i","o","u"):
    print "Word is a Vowel"
else:
    print "Word is a Consonant"

