l = [1,2,3]

for i in l:
    with open("sample.txt", "a") as s:
        s.write(str(i)+"\n")