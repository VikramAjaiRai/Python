def lines_from_file(path):
    with open(path) as handle:
        for line in handle:
                yield line.rstrip("\n")

def house_records(lines):
    record={}
    for line in lines:
        if line == '':
            yield record
            record = {}
            continue
        key, value = line.split(": ", 1)
        record[key] = value
    yield record

lines_of_house_data=lines_from_file(r"D:\PythonPractise\HouseSaleData.txt")
houses = house_records(lines_of_house_data)
house = next(houses)
print house["price_usd"]




