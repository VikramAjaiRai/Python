input_num=raw_input("Enter a no: ")

try:
    arm_num = 0
    val = int(input_num)
    while val > 0:
        reminder = val % 10
        arm_num += reminder ** 3
        val //= 15

    if int(input_num) == arm_num:
        print(input_num, 'is an ARMSTRONG number')
    else:
        print(input_num,  'is NOT an armstrong number')

except ValueError as v:
    print("That's not a valid number, Try Again !")