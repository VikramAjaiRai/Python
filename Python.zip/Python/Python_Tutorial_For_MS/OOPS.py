class Car(object):
    def __init__(self, speed, registration,topspeed=250):
        self.speed=speed
        self.topspeed=topspeed
        self.registration=registration

    def Speed(self):
        print "The speed of car is {}".format(self.speed)
    def Topspeed(self):
        print "The topspeed of car is {}".format(self.topspeed)
    def Registration(self):
        print "The registration number of the car is {}".format(self.registration)
    def accelerator(self):
        if self.speed > self.topspeed:
            raise Exception("Speed is more than top speed")
        else:
            print "Speed is normal. The speed is {}".format(self.speed)

if __name__ == "__main__":
    try:
        obj1 = Car(888, 12345)
        obj1.accelerator()
    except Exception as e:
        print e



