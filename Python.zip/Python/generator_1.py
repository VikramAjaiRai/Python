def lines_from_file(path):
    with open(path) as handle:
        for line in handle:
                yield line.rstrip("\n")
def matching_lines(lines,pattern):
    for line in lines:
        if pattern in line:
            yield line
def matching_lines_from_log(pattern,path):
    lines=lines_from_file("log.txt")
    matching=matching_lines(lines, pattern)

    for line in matching:
        yield line



lines=lines_from_file("log.txt")
matching_lines(lines, "WARNING:")
