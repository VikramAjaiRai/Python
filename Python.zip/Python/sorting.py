a=student_tuples = [('John', 'a', 15),('Jane', 'B', 12),('john', 'C', 10),('David', 'c', 10),('Victor', 'b', 10), ]

b = sorted(a, key=lambda x:x[0].upper(), reverse=False)[-2:]

print b
