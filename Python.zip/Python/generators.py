def matching_lines_from_file(path, pattern):
    with open(path) as handle:
        for line in handle:
            if pattern in line:
                yield line.rstrip("\n")

def parse_log_records(lines):
    for line in lines:
        level,message=line.split(": ", 1)
        yield {"level": level, "message": message }

log_lines=matching_lines_from_file(r"D:\PythonPractise\log.txt","WARNING")

for record in parse_log_records(log_lines):
    print record
