def func(**kwargs):
    print str(kwargs)

func(a=12,b=13,c=14)