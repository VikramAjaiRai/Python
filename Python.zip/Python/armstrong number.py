i_n=raw_input("Please enter a number: ")
a=(map(int, i_n))
b=(map(lambda x:x**3, a))
c=sum(b)
print c

