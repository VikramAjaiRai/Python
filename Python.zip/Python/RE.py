import re
str = "Twinkle, twinkle, little star!"
l=re.split(r'\W+',str)
print l
