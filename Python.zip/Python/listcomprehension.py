listOfWords = ["this","is","a","list","of","words"]

final = [i[0].capitalize() for i in listOfWords]
print final
