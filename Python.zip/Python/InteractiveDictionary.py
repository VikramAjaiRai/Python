'''This prgrams is a smart dictinary which populates the meaning of the word entered by user.
There are many smart implemention done which can be seen while trying this dictionary
Happy dictinary-ing'''
import json
from difflib import get_close_matches
import time

data=json.load(open(r"D:\PythonPractise\InteractiveDictionary\data.json"))

def translate(w):
    w=w.lower()

    if w in data:
        return data[w]
    elif w.title() in data:
        return data[w.title()]
    elif len(get_close_matches(w, data.keys())) > 0:
        user_input=raw_input("did you mean --{}-- instead? Enter Y if yes or enter N if no -->".format(get_close_matches(w, data.keys())[0]))
        if user_input == "Y":
            return data[get_close_matches(w, data.keys())[0]]
        elif user_input == "N":
            return "You have Entered N and hence you will be less knowledgeable than the user who pressed Y"
        elif user_input != "Y" or "N":
            user_input1 = raw_input("You were given two options, atleast select Y or N: ")
            if user_input1 == "Y":
                return data[get_close_matches(w, data.keys())[0]]
            elif user_input1 == "N":
                return "You have Entered N and hence you will be less knowledgeable than the user who pressed Y"
            else:
                return "You have not given input(Y or N) the second time properly. You are here for timepass and not for gaining the knowledge. Good-Bye!!"
        #else:
            #pass

    elif w == "":
        return "You have to type atleast an alphabet. Existing the Dictionary"
    else:
        return "The word you entered is either empty string or incorrect. Please check the word again"


print __doc__+"\n"
time.sleep(2)
raw_input("After reading the description, please go ahead with the word.Click at the end of this line if cursor seems invisible. Press Enter to proceed: ")
x=raw_input("Please enter a word: ")
output= translate(x)

if type(output) == list:
    n = 1
    for item in output:
        print str(n)+"."+"{}".format(item)
        n+=1
else:
    print output









