#fanning out: When the input is one and output is many
def words_in_text(lines):
        for line in lines:
            for words in line.split():
                yield words,

def lines_from_file(path):
    with open(path) as handle:
        for line in handle:
                yield line.rstrip("\n")
poem_lines=lines_from_file("poem.txt")
poem_words=words_in_text(poem_lines)
l=[]
for word in poem_words:
    l.append(word)
print l